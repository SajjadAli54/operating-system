#include "iostream"
#include "string.h"
#include "fstream"
#include "time.h"
#include "omp.h"

using namespace std;

int occurrence(string book_word){
    int occurrence = 0;
    ifstream file("hello.txt");
    string word;
    file >> word;
    while(!file.eof()){
        if(word == book_word)
            occurrence++;
        file >> word;
    }
    file.close();
    return occurrence;
}

void search(string word){
    int occurr = occurrence(word);
    cout << word;
    printf(" appears in the text %d \n",occurr);
}

int main(){
    string a = "Java", b = "a", c = "not", d = "an";
    clock_t start, end;
    start = clock();
    #pragma omp parallel sections thread_num(1)
    {
        #pragma omp section
        {
            search(a);
        }
        
        #pragma omp section
        {
            search(b);
        }

        #pragma omp section
        {
            search(c);
        }

        #pragma omp section
        {
            search(d);
        }
    }
    end = clock();
    double time = 1000 * (double)(end - start) /CLOCKS_PER_SEC;
    cout << time << endl;
    
    return 0;
}