#!/bin/bash

function crawler(){
	ls -R | grep '\.txt$'  
}

crawler

